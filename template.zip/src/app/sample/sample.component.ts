import {Component, OnInit} from '@angular/core';
import { Vehicle } from '../vehicle';
import { from } from 'rxjs';
import {VehicleService} from '../vehicle.service';
import { identifierModuleUrl } from '@angular/compiler';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'template-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.less']
})
export class SampleComponent implements OnInit {

  vehicles : Vehicle[];
  selectedVehicle : Vehicle;
  constructor(private vehicleService:VehicleService,private http: HttpClient) {
  }

  ngOnInit() {
    this.getVehicles();
  
  }

  onSelect(vehicle: Vehicle): void {
    this.selectedVehicle = vehicle;
  }
  getVehicles(): void{
    this.vehicleService.getVehicles().subscribe(
       vehicles => { 
         this.vehicles = vehicles; 
         this.vehicleService.success('fetched vehicles'); 
        }, 
        error => { 
          this.vehicleService.error('Unable to fetch vehicles'); 
          console.error(error); }
           );
  }

  add(name: string): void { 
    name = name.trim();
     if (!name) 
     { 
       return;
       } 
       this.vehicleService.addVehicle({ name } as Vehicle) .subscribe(vehicle => {
          this.vehicles.push(vehicle); 
           this.vehicleService.success('Vehicle successfully added');
           },
            error => { 
              this.vehicleService.error('Unable to add vehicle'); 
              console.log(error); 
            }
            ); 
          }

     updateVehicle(vehicle: Vehicle): void {
    
       this.vehicleService.updateVehicle(vehicle).subscribe(vehicle =>{
          this.vehicleService.updateVehicle(vehicle);
       })
     }      
    
}
