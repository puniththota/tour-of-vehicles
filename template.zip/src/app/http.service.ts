import {Injectable} from '@angular/core';
 import {HttpClient, HttpHeaders} from '@angular/common/http'; 
 import 'rxjs/add/operator/map';
 
 @Injectable() 
 
 export class HttpService
  { /* Here is where you configure your base URL. The base URL is the connection used to connect to the server. The following is an example of a connection made to a remote server */
     server = 'localhost'; 
     port = '7001'; 
     protocol = 'http'; 
     baseUrl = this.protocol + '://' + this.server + ':' + this.port;

/* Since we are using a simulated server we will use this for our base URL */ 

private vehiclesUrl = 'api/vehicles';
 constructor(private http: HttpClient) { }
 
 /* Occasionally you will need to configure your headers. Here is where you will do that, otherwise it will just use default headers. This header will be attached to all HTTP calls made. */
  private createHeaders(headersObj): HttpHeaders { headersObj = headersObj ? headersObj : {}; 

  const token = 'eyJ0eXAiOiJKV1QiLCJjdHkiOm51bGwsImFsZyI6IkhTMjU2In0.eyJzdWIiOnsiZ21pbiI6ImRlbWFuZFNjaGVkLmNvbSIsImdtaWQiOiJkZW1hbm' + 
  'RTY2hlZC5jb20iLCJhY2NvdW50dHlwZSI6IlN5c3RlbSIsImFwcFJvbGUiOlsiQ049VUctV1BQLU1GRy1HU01TLURlbWFuZFNjaGVkdWxlci1TQ1MsT1U9U2VjdXJp' +
   'dHkgR3JvdXBzLE9VPVByb2Nlc3MsT1U9Q29tbW9uLE9VPU1hbnVmYWN0dXJpbmcsT1U9VW5pdGVkIFN0YXRlcyxEQz1uYW0sREM9Y29ycCxEQz1nbSxEQz1jb20iXX' + 
   '0sImlzcyI6Imh0dHAvL2RjbWl0YXZnbWwwMTk0LmVwZ2EubmFtLmdtLmNvbTo4NDQzOjg0NDMvYXBpL3NlY3VyaXR5IiwiYXVkIjpudWxsLCJleHAiOjE2Nzc1OTcx' + 
   'MjQsImlhdCI6MTUxOTkxNzEyNCwianRpIjoiYjUyMTMyZWYtZjc5ZS00ZDNhLTgwYzktN2Q3NWMzN2VlOTc1In0.sHDXYphRJ7waRV_TgocbB7VlGXr0OuBK5-XMf7t77s4'; 

  const contentType = 'application/json'; 
  const accept = 'application/json'; 
  headersObj['tonic_id'] = headersObj['tonic_id'] ? headersObj['tonic_id'] : token;
   headersObj['Content-Type'] = headersObj['Content-Type'] ? headersObj['Content-Type'] : contentType;
    headersObj['Accept'] = headersObj['Accept'] ? headersObj['Accept'] : accept; 
    return new HttpHeaders(headersObj); 
} 
/* This will attach what we send the URL to the base URL */
private prependRequest(url) {
    
    /* Comment out this line and uncomment the baseURL line below when switching to a real
server */ 
return this.vehiclesUrl + url; 
 //return this.baseUrl + url; 
} 
/* With this method we will specify type of http call we are using, what we are appending to the baseURL (EX: parameters lk '/{id}', or path) */ 
sendRequest(urlObj: { URL: string, METHOD: string, headers?: Object }, body?: Object) { 
    const headers = this.createHeaders(urlObj.headers); 
    urlObj.URL = this.prependRequest(urlObj.URL); let response = null; 
    if (urlObj.METHOD === 'GET')
     { 
         response = this.http.get(urlObj.URL, {headers: headers}); 
    } 
    else if (urlObj.METHOD === 'POST') 
    { 
        response = this.http.post(urlObj.URL, body, {headers: headers} );
     } 
     else if (urlObj.METHOD === 'PUT')
      { 
          response = this.http.put(urlObj.URL, body, {headers: headers});
     }
      else if (urlObj.METHOD === 'DELETE') 
      { 
          response = this.http.delete(urlObj.URL, {headers: headers});
         } 
         else 
         { 
             console.log('Error, urlObj method %s was invalid!', urlObj.METHOD); 
            } 
            return response;
         } 
        }