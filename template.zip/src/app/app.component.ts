import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent {
	sidebarOpen: boolean = false;
	title = 'gm';

	openSidebar(isOpen: boolean): void {
		this.sidebarOpen = isOpen || false;
	}

	closeSidebar(){
		this.sidebarOpen = false;
	}
}
