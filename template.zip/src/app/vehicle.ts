export class Vehicle {
    id: number;
    name: string;
}