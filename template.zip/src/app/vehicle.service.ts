import { Vehicle } from './vehicle'; 
import { VEHICLES } from './mock-vehicle';
import {Observable, of } from 'rxjs';
import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { HttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {
  success(message: string) {
    setTimeout(()=> this.toast.success(`VehicleService: ${message}`));
  }
  error(message: string) {
    setTimeout(()=> this.toast.error(`VehicleService: ${message}`));
  }

  private vehiclesUrl = 'api/vehicles';
  constructor(
    private httpSvc: HttpService,
    private http: HttpClient,
    private toast: ToastrService) { }

  getVehicles(): Observable<Vehicle[]> { 
     setTimeout(()=> this.toast.success('VehicleService: fetched vehicles '));
    // return of(VEHICLES); 
  //  return this.http.get<Vehicle[]>(this.vehiclesUrl);
   const urlObj = {
     METHOD: 'GET',
     URL: ''
   };
      return this.httpSvc.sendRequest(urlObj);
  }
  getVehicle(id: number): Observable<Vehicle> { 
    // setTimeout(() => this.toast.success(`VehicleService: fetched vehicle id = ${id}`)); 
    // return of(VEHICLES.find(vehicle => vehicle.id === id));
    // const url = `${this.vehiclesUrl}/${id}`; 
    // return this.http.get<Vehicle>(url);
    const urlObj = { 
      METHOD: 'GET', 
      URL: '/' + id 
    }; 
    return this.httpSvc.sendRequest(urlObj, id); 
  }

  /** POST: add a new vehicle to the server */ 
  addVehicle(vehicle: Vehicle): Observable<Vehicle> {
     const urlObj = { 
       METHOD: 'POST',
        URL: '' 
      }; 
      return this.httpSvc.sendRequest(urlObj, vehicle); }

      updateVehicle(vehicle: Vehicle): Observable<Vehicle>{
        const urlObj = {
          METHOD: 'PUT',
          URL: ''
        };
        return this.httpSvc.sendRequest(urlObj,vehicle);
      }
}
