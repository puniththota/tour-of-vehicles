import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {SampleComponent} from './sample/sample.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { VehicleDetailComponent } from './vehicle-detail/vehicle-detail.component';

const routes: Routes = [
  {
    path: 'sample',
    component: SampleComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
   path: 'detail/:id',
   component: VehicleDetailComponent
  },
  {
    path: '**',
    redirectTo: '/sample',
    pathMatch: 'full'
  },
  
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
