import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {CoreModule} from './core/core.module';
import {SampleComponent} from './sample/sample.component';
import {DesignLibraryModule} from './design-library/design-library.module';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ToastrModule} from 'ngx-toastr';
import { VehicleDetailComponent } from './vehicle-detail/vehicle-detail.component';
import {VehicleService} from './vehicle.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { InMemoryDataService } from './in-memory-data.service';
import { HttpService } from './http.service';


@NgModule({
  declarations: [
    AppComponent,
    SampleComponent,
    VehicleDetailComponent,
    DashboardComponent
  ],
  imports: [
    HttpClientModule,
    HttpClientInMemoryWebApiModule.forRoot(
      InMemoryDataService, {dataEncapsulation:false}
    ),
    BrowserModule,
    AppRoutingModule,
    CoreModule,
    DesignLibraryModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    
  ],
  providers: [VehicleService,HttpService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
