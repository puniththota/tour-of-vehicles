import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import 'rxjs/add/operator/filter';

@Component( {
  selector: 'gm-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: [ './sidebar.component.less' ]
} )
export class SidebarComponent implements OnInit {
  @Input() sidebarOpen: boolean;
  @Output() closeSidebar: EventEmitter<boolean> = new EventEmitter<boolean>();
  currentRoute = '/home';

  constructor( private router: Router ) {}

  ngOnInit() {
    this.router.events.filter( (event: any) => event instanceof NavigationEnd )
      .subscribe( resp => {
        this.currentRoute = resp.url;
      } );
  }

  selectRoute( location ) {
    this.router.navigate( [ location ] );
    console.log( this.currentRoute );
    this.currentRoute = location;
  }

  changeLanguage() {
  }

  changeDateFormat() {
  }

  login() {
  }

  logout() {
  }

  emitCloseSidebar() {
    this.sidebarOpen = false;
    this.closeSidebar.emit();
  }
}
