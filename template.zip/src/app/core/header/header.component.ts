import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
	selector: 'gm-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.less']
})
export class HeaderComponent implements OnInit {
	@Input() sidebarOpen: boolean;
	@Output() openSidebar: EventEmitter<boolean> = new EventEmitter<boolean>();
	currentDate: Date = new Date();

	constructor() { }

	ngOnInit() {
	}

	toggleSidebar(): void{
		this.sidebarOpen = !this.sidebarOpen;
		this.openSidebar.emit(this.sidebarOpen);
	}

	logout(): void{
		throw new Error('Logout functionality not implemented.');
	}

	changeLanguage(): void{
		throw new Error('Language functionality not implemented.');
	}

}
