import { Component, OnInit, Input } from '@angular/core';
import {Vehicle } from '../vehicle';
import {ActivatedRoute} from '@angular/router'; 
import {Location} from '@angular/common'; 
import {VehicleService} from '../vehicle.service';

@Component({
  selector: 'template-vehicle-detail',
  templateUrl: './vehicle-detail.component.html',
  styleUrls: ['./vehicle-detail.component.less']
})
export class VehicleDetailComponent implements OnInit {

  @Input() vehicle: Vehicle;

  constructor(
    private route: ActivatedRoute,
     private vehicleService: VehicleService, 
     private location: Location) { }

  ngOnInit() {
    this.getVehicle();
  }

  getVehicle(): void { 
    const id = +this.route.snapshot.paramMap.get('id'); 
    this.vehicleService.getVehicle(id).subscribe( vehicle => { 
      this.vehicle = vehicle; this.vehicleService.success('fetched vehicle');
     },
      error => { this.vehicleService.error('Unable to fetch vehicle');
       console.error(error);
       } 
       );
       }

      //  save(vehicle): void{
      //    this.vehicleService.updateVehicle(vehicle).subscribe( vehicle=> {

      //    })
      //  }
}
