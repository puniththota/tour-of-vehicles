import { InMemoryDbService } from 'angular-in-memory-web-api';
 import { Vehicle } from './vehicle'; 
 import { Injectable } from '@angular/core';
 
 @Injectable({ 
   providedIn: 'root' 
  }) 
  
  export class InMemoryDataService implements InMemoryDbService {
    
    createDb() { 
      const vehicles = [
         { id: 11, name: 'Camaro' },
            { id: 12, name: 'Bolt' }, 
            { id: 13, name: 'Yukon' }, 
            { id: 14, name: 'Regal' }, 
            { id: 15, name: 'Silverado' },
             { id: 16, name: 'Sierra' },
            { id: 17, name: 'Escalade' }, 
            { id: 18, name: 'XT5' }, 
            { id: 19, name: 'Corvette' },
             { id: 20, name: 'Enclave' }
             ]; 
             return {vehicles};
             } 
             // if the vehicles array is not empty, the method below returns the highest // vehicle id + 1. 
             genId(vehicles: Vehicle[]): number
              { 
                return vehicles.length > 0 ? Math.max(...vehicles.map(hero => hero.id)) + 1 : 11;
               } 
              }