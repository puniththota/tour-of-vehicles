import { Vehicle } from './vehicle';

export const VEHICLES: Vehicle[] = [
    {id: 11,name: 'Camaro'},
    {id: 12,name: 'Bolt'},
    {id: 13,name: 'Yukon'},
    {id: 14,name: 'Regal'},
    {id: 15,name: 'Silverado'},
    {id: 16,name: 'Sierra'},
    {id: 17,name: 'Escalade'},
    {id: 18,name: 'XT5'},
    {id: 19,name: 'Corvette'},
    {id: 20,name: 'Enclave'}
];