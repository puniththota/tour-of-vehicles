import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'gm-loading-spinner-overlay',
  templateUrl: './loading-spinner-overlay.component.html',
  styleUrls: ['./loading-spinner-overlay.component.less']
})
export class LoadingSpinnerOverlayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
