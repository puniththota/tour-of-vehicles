import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {ModalComponent} from './modal.component';
import {By} from '@angular/platform-browser';
import {DebugElement} from '@angular/core';
import {Button} from 'app/shared/button.model';

fdescribe('ModalComponent', () => {
  let component: ModalComponent;
  let fixture: ComponentFixture<ModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ModalComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should have passed in class in modal-dialog element', () => {
    component.visible = true;
    component.class = 'my-class';
    fixture.detectChanges();

    let modalDialogElement = fixture.debugElement.query(By.css('.modal-dialog'));

    expect(modalDialogElement.properties.className).toContain('my-class');
  });

  it('should display modal title in title element', () => {
    component.visible = true;
    component.modalTitle = 'this is the passed in title';
    fixture.detectChanges();

    let titleElement = fixture.debugElement.query(By.css('#title'));

    expect(titleElement.nativeElement.textContent).toContain('this is the passed in title');
  });

  it('should display passed in message inside the modal body', () => {
    component.visible = true;
    component.message = 'this is a passed in message';
    fixture.detectChanges();

    let messageElement = fixture.debugElement.query(By.css('.modal-body .modal-body-section'));

    expect(messageElement.nativeElement.textContent).toContain('this is a passed in message');
  });

  it('should close when x is clicked', () => {
    component.visible = true;
    fixture.detectChanges();

    let xElement = fixture.debugElement.query(By.css('span.pull-right'));
    let visibility: boolean;

    component.visibleChange.subscribe((visible: boolean) => visibility = visible);

    xElement.triggerEventHandler('click', null);
    expect(visibility).toBe(false);
    expect(component.visible).toBe(false);
  });

  describe('buttons', () => {
    var modalButtons: Button[];
    var testBoolean: boolean = false;
    var firstButtonElement: DebugElement;
    var secondButtonElement: DebugElement;

    beforeEach(() => {
      modalButtons = [
        {
          text: 'Button 1',
          className: 'btn btn-primary',
          clickMethod: () => {
            testBoolean = true;
          },
          isDisabled: () => {
            return true;
          }
        },
        {
          text: 'Button 2',
          className: 'btn btn-secondary',
          clickMethod: () => {
            testBoolean = false;
          },
          isDisabled: () => {
            return false;
          }
        }
      ];

      component.buttons = modalButtons;
      component.visible = true;
      fixture.detectChanges();

      firstButtonElement = fixture.debugElement.query(By.css('button.btn.btn-primary'));
      secondButtonElement = fixture.debugElement.query(By.css('button.btn.btn-secondary'));
    });

    it('should contain correct text', () => {
      expect(firstButtonElement.nativeElement.textContent).toContain('Button 1');
      expect(secondButtonElement.nativeElement.textContent).toContain('Button 2');
    });

    it('should be disabled when passed in button isDisabled function evaluates to true', () => {
      let firstDisabledProperty: boolean = firstButtonElement.properties.disabled;
      expect(firstDisabledProperty).toBe(true);

      let secondDisabledProperty: boolean = secondButtonElement.properties.disabled;
      expect(secondDisabledProperty).toBe(false);
    });

    it('should perform passed in clickMethod when clicked', () => {
      firstButtonElement.triggerEventHandler('click', null);
      expect(testBoolean).toBe(true);

      secondButtonElement.triggerEventHandler('click', null);
      expect(testBoolean).toBe(false);
    });
  });
});
