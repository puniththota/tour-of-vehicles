import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Button } from "./button.model";

@Component({
	selector: 'gm-modal',
	templateUrl: './modal.component.html',
	styleUrls: ['./modal.component.less']
})
export class ModalComponent implements OnInit {
	@Input() modalTitle: string = '';
	@Input() buttons: Button[];
	@Input() visible: boolean = false;
	@Output() visibleChange : EventEmitter<boolean> = new EventEmitter<boolean>();
	@Input() message: string = '';
	@Input() class: string = 'modal-md';

	constructor() { }

	ngOnInit() {
	}

	hideModal(){
		this.visible = false;
		this.visibleChange.emit(this.visible);
	}

}
