import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'gm-showcase',
  templateUrl: './showcase.component.html',
  styleUrls: ['./showcase.component.less']
})
export class ShowcaseComponent implements OnInit {
  @Input('showcase-title') title: string;
  @Input() showBackButton: boolean = false;
  @Input() blurBackground: boolean = false;

  constructor() { }

  ngOnInit() {
  }

}
