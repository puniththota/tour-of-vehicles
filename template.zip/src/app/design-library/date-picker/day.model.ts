export class Day {
    label: number;
    today: boolean;
    selected: boolean;
    previousMonth: boolean;
    nextMonth: boolean;
    disabled: boolean;
    date: Date;
}
