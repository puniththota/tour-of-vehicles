export class TimeOptions {

  timeFormat24Hrs: boolean;
  includeTimePicker: boolean;
  timePickerOnly: boolean;
}


