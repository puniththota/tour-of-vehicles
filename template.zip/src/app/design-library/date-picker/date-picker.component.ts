import {Component, OnInit, Input, forwardRef, ElementRef, HostListener} from '@angular/core';
import {Day} from './day.model';
import {ControlValueAccessor, NG_VALUE_ACCESSOR} from '@angular/forms';
import {TimeOptions} from './TimeOptions.model';

@Component({
  selector: 'gm-datepicker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.less'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => DatePickerComponent),
      multi: true
    }
  ]
})
export class DatePickerComponent implements OnInit, ControlValueAccessor {

  calendarView = true;
  timeView = false;
  monthView = false;

  @Input() label: String;
  @Input() timeOptions: TimeOptions;
  datePickerOpen = false;
  today: Date;
  currentHour: number = new Date().getHours();
  currentMinute: number = new Date().getMinutes();
  currentMonth: number = new Date().getMonth();
  currentMeridiem = this.currentHour >= 12 ? 'PM' : 'AM';
  hourToSet: number = this.currentHour;
  monthToSet: number = this.currentMonth;
  meridiemPM = false;
  meridiemAM = false;
  displayedHour: number = this.currentHour;
  displayedMinute: number = this.currentMinute;
  displayedMeridiem = this.displayedHour >= 12 ? 'PM' : 'AM';
  displayedMonth: number;
  displayedYear: number;
  displayedDays: Day[];
  selectedDate: Date;
  selectedTime: Date;
  @Input() minDate: Date;
  @Input() maxDate: Date;
  isDisabled: boolean;
  hasError: boolean;

  months = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ];

  abrMonths = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];

  constructor(private _eref: ElementRef) {
  }

  @HostListener('document:click', ['$event'])
  onClick(event) { //Checks if the user clicks outside of the following items and if so closes the date picker
    if (!this._eref.nativeElement.contains(event.target) && event.target.id !== 'view-month' && event.target.id !== 'view-time'
      && event.target.id !== 'view-calendar' && event.target.id !== 'view-time-from-month' && event.target.id !== 'select-month'
      && event.target.id !== 'view-calendar-icon' && event.target.id !== 'view-time-icon-from-month' && event.target.id !== 'view-time-icon'
      && event.target.className !== 'row toggle-button') {
      this.closeDatePicker();
    }
  }

  ngOnInit() {
    this.today = new Date();
    // this.today.setHours(0, 0, 0, 0);

    this.twelveHourReset();
  }

  checkTimePickerOptions() {
    if (this.timeOptions.includeTimePicker === true && this.timeOptions.timePickerOnly === true) {
      console.error('timePickerIncluded and timePickerOnly cannot both be set to true. Only one option is allowed to be true at a time.');
      this.hasError = true;
    }
  }

  changeDatePickerView() {
    if (this.calendarView === true) {
      this.calendarView = !this.calendarView;
    } else {
      this.monthView = !this.monthView;
    }
    this.timeView = !this.timeView;

    if (this.timeView === false) {
      this.monthView = !this.monthView;
      this.calendarView = true;
    }
  }

  getTimeFormat() {
    if (this.timeOptions.timeFormat24Hrs && this.timeOptions.includeTimePicker) {
      return 'M/d/yy, HH:mm';
    } else if (!this.timeOptions.timeFormat24Hrs && this.timeOptions.includeTimePicker) {
      return 'short';
    }  else if (this.timeOptions.timePickerOnly && !this.timeOptions.timeFormat24Hrs) {
      return 'hh:mm a';
    } else if (this.timeOptions.timePickerOnly && this.timeOptions.timeFormat24Hrs) {
      return 'HH:mm';
    } else if (!this.timeOptions.includeTimePicker) {
      return 'shortDate';
    }
  }

  showMonthSelectorView() {
    this.calendarView = !this.calendarView;
    this.monthView = !this.monthView;
  }

  twelveHourReset() {
    if (!this.timeOptions.timeFormat24Hrs && this.displayedHour > 12) {
      this.displayedHour = this.displayedHour - 12;
    }
  }

  updateToPM() {
    this.displayedMeridiem = 'PM';
    this.meridiemPM = true;
    if (this.currentMeridiem != this.displayedMeridiem || this.meridiemAM) {
      if (this.hourToSet < 12) {
        this.hourToSet = this.hourToSet + 12;
      } else {
        this.hourToSet = this.hourToSet + 12 - 23;
      }
      this.meridiemAM = false;
    }
  }

  updateToAM() {
    this.displayedMeridiem = 'AM';
    this.meridiemAM = true;
    if (this.currentMeridiem != this.displayedMeridiem || this.meridiemPM) {
      if (this.hourToSet > 12) {
        this.hourToSet = this.hourToSet - 12;
      }
      this.meridiemPM = false;
    }
  }

  decreaseHour() {
    if (this.timeOptions.timeFormat24Hrs == true) {
      if (this.displayedHour > 0) {
        this.displayedHour = this.displayedHour - 1;
      } else {
        this.displayedHour = 23;
      }
    } else {

      if (this.displayedHour > 1) {
        this.displayedHour = this.displayedHour - 1;
      } else {
        this.displayedHour = 12;
      }

      if (this.hourToSet > 0) {
        this.hourToSet = this.hourToSet - 1;
      } else {
        this.hourToSet = 23;
      }

      if (this.hourToSet >= 0 && this.hourToSet <= 11) {
        this.displayedMeridiem = 'AM';
      } else if (this.hourToSet >= 12 && this.hourToSet <= 23) {
        this.displayedMeridiem = 'PM';
      }
    }
  }

  increaseHour() {
    if (this.timeOptions.timeFormat24Hrs == true) {
      if (this.displayedHour < 23) {
        this.displayedHour = this.displayedHour + 1;
      } else {
        this.displayedHour = 0;
      }
    } else {

      if (this.displayedHour < 12) {
        this.displayedHour = this.displayedHour + 1;
      } else {
        this.displayedHour = 1;
      }

      if (this.hourToSet < 23) {
        this.hourToSet = this.hourToSet + 1;
      } else {
        this.hourToSet = 0;
      }

      if (this.hourToSet >= 0 && this.hourToSet < 12) {
        this.displayedMeridiem = 'AM';
      } else if (this.hourToSet >= 12 && this.hourToSet < 23) {
        this.displayedMeridiem = 'PM';
      }
    }

  }

  decreaseMinute() {
    if (this.displayedMinute > 0) {
      this.displayedMinute = this.displayedMinute - 1;
    } else {
      this.displayedMinute = 59;
    }
  }

  increaseMinute() {
    if (this.displayedMinute < 59) {
      this.displayedMinute = this.displayedMinute + 1;
    } else {
      this.displayedMinute = 0;
    }
  }

  selectTime() {
    this.selectedTime = new Date();
    if (!this.timeOptions.timeFormat24Hrs) {
      this.selectedTime.setHours(this.hourToSet);
    } else {
      this.selectedTime.setHours(this.displayedHour);
    }
    this.selectedTime.setMinutes(this.displayedMinute);
    this.closeDatePicker();
  }

  selectCurrentTime(): void {
    if (!this.timeOptions.timePickerOnly) {
      this.selectToday();
    } else {
      this.selectedTime = new Date();
      this.closeDatePicker();
    }
  }

  selectCurrentMonth() {
    this.displayedMonth = this.currentMonth;
    this.monthToSet = this.currentMonth;
    this.showMonthSelectorView();
  }

  selectedMonth(index) {
    this.displayedMonth = index;
    this.monthToSet = index;
    this.showMonthSelectorView();
  }

  writeValue(value: any) {
    if (value !== undefined) {
      this.selectedDate = value;
    }

    if (this.selectedDate) {
      this.propagateChange(this.selectedDate);
      this.displayedMonth = this.selectedDate.getMonth();
      this.displayedYear = this.selectedDate.getFullYear();
    } else {
      this.displayedMonth = this.today.getMonth();
      this.displayedYear = this.today.getFullYear();
    }

    this.displayedDays = this.generateDaysFor(this.displayedMonth, this.displayedYear);
  }

  propagateChange = (_: any) => {
  };

  registerOnChange(fn) {
    this.propagateChange = fn;
  }

  registerOnTouched() {
  }

  setDisabledState(isDisabled: boolean): void {
    this.isDisabled = isDisabled;
    this.datePickerOpen = false;
  }

  openDatePicker(): void {
    this.checkTimePickerOptions();
    if (!this.isDisabled && !this.hasError) {
      this.datePickerOpen = true;
    }
    if (this.timeOptions.timePickerOnly) {
      this.calendarView = false;
      this.timeView = true;

      if (this.selectedTime != null) {
        this.displayedHour = this.selectedTime.getHours();
        this.displayedMinute = this.selectedTime.getMinutes();
        if (!this.timeOptions.timeFormat24Hrs) {
          this.hourToSet = this.displayedHour;
          this.twelveHourReset();
          if (this.hourToSet > 0 && this.hourToSet <= 11) {
            this.displayedMeridiem = 'AM';
          } else if (this.hourToSet > 11 && this.hourToSet <= 23) {
            this.displayedMeridiem = 'PM';
          }
        }
      }
    }
  }

  closeDatePicker(): void {
    this.datePickerOpen = false;
    if (this.selectedDate != null) {
      this.displayedHour = this.selectedDate.getHours();
      this.hourToSet = this.selectedDate.getHours();
      this.displayedMinute = this.selectedDate.getMinutes();
      this.monthToSet = this.selectedDate.getMonth();
      this.displayedMeridiem = this.displayedHour >= 12 ? 'PM' : 'AM';
    } else {
      this.displayedHour = this.currentHour;
      this.displayedMinute = this.currentMinute;
      this.hourToSet = this.currentHour;
      this.displayedMonth = this.currentMonth;
      this.displayedMeridiem = this.currentHour >= 12 ? 'PM' : 'AM';
    }
    this.twelveHourReset();
  }

  switchToPreviousMonth(): void {
    if (this.displayedMonth == 0) {
      this.displayedMonth = 11;
      this.displayedYear = this.displayedYear - 1;
    } else {
      this.displayedMonth = this.displayedMonth - 1;
    }
    this.displayedDays = this.generateDaysFor(this.displayedMonth, this.displayedYear);
  }

  switchToNextMonth(): void {
    if (this.displayedMonth == 11) {
      this.displayedMonth = 0;
      this.displayedYear = this.displayedYear + 1;
    } else {
      this.displayedMonth = this.displayedMonth + 1;
    }
    this.displayedDays = this.generateDaysFor(this.displayedMonth, this.displayedYear);
  }

  selectDate(day): void {
    if (!day.disabled) {
      if (!this.timeOptions.timeFormat24Hrs) {
        day.date.setHours(this.hourToSet);
      } else {
        day.date.setHours(this.displayedHour);
      }
      day.date.setMinutes(this.displayedMinute);
      day.date.setMonth(this.monthToSet);

      this.selectedDate = new Date(day.date.getFullYear(), day.date.getMonth(), day.date.getDate(), day.date.getHours(), day.date.getMinutes());
      this.propagateChange(this.selectedDate);

      this.displayedDays.forEach(otherDay => {
        otherDay.selected = false;
      });
      day.selected = true;

      if (day.previousMonth) {
        this.switchToPreviousMonth();
      } else if (day.nextMonth) {
        this.switchToNextMonth();
      }

      this.closeDatePicker();
    }
  }

  selectToday(): void {
    this.selectedDate = new Date();
    this.selectedDate.setHours(this.currentHour);
    this.selectedDate.setMinutes(this.currentMinute);
    this.propagateChange(this.selectedDate);

    this.displayedMonth = this.selectedDate.getMonth();
    this.displayedYear = this.selectedDate.getFullYear();
    this.displayedDays = this.generateDaysFor(this.displayedMonth, this.displayedYear);

    this.closeDatePicker();
  }

  disableToday(): boolean {
    if (this.minDate) {
      if (this.today.getTime() < this.minDate.getTime()) {
        return true;
      }
    }

    if (this.maxDate) {
      if (this.today.getTime() > this.maxDate.getTime()) {
        return true;
      }
    }

    return false;
  }

  showClearDate(): boolean {
    if (this.isDisabled) {
      return false;
    }

    if (this.selectedDate || this.selectedTime) {
      return true;
    }

    return false;
  }

  clearDate(event): void {
    this.selectedDate = null;
    this.selectedTime = null;
    this.propagateChange(this.selectedDate);
    this.displayedDays.forEach(day => {
      day.selected = false;
    });
    this.closeDatePicker();
    event.stopPropagation();
  }

  dateClasses(day: Day) {
    var classes = {
      'different-month': day.nextMonth || day.previousMonth,
      'today': day.today,
      'selected': day.selected,
      'disabled': day.disabled
    };

    return classes;
  }

  private numberOfDaysIn(month: number, year: number): number {
    if (month == 0 || month == 2 || month == 4 || month == 6 || month == 7 || month == 9 || month == 11) {
      return 31;
    } else if (month == 3 || month == 5 || month == 8 || month == 10) {
      return 30;
    } else if (month == 1) {
      if (year % 4 == 0) {
        if (year % 100 == 0) {
          if (year % 400 == 0) {
            return 29;
          }
          return 28;
        }
        return 29;
      }
      return 28;
    }
    return 0;
  }

  private generateDaysFor(month: number, year: number): Day[] {
    var days: Day[] = [];

    var numberOfDaysInDisplayedMonth = this.numberOfDaysIn(month, year);
    var firstOfMonth = new Date(year, month, 1);
    var numberOfDaysFromPreviousMonth = firstOfMonth.getDay();
    var previousMonth: number;
    var yearForPreviousMonth: number;
    if (month == 0) {
      previousMonth = 11;
      yearForPreviousMonth = year - 1;
    } else {
      previousMonth = month - 1;
      yearForPreviousMonth = year;
    }
    ;
    var numberOfDaysInPreviousMonth = this.numberOfDaysIn(previousMonth, year);

    var firstDayFromPreviousMonth = numberOfDaysInPreviousMonth - numberOfDaysFromPreviousMonth + 1;
    var labelFromPreviousMonth: number;
    for (labelFromPreviousMonth = firstDayFromPreviousMonth; labelFromPreviousMonth <= numberOfDaysInPreviousMonth; labelFromPreviousMonth++) {
      var day: Day = {
        label: labelFromPreviousMonth,
        today: false,
        selected: false,
        previousMonth: true,
        nextMonth: false,
        disabled: false,
        date: new Date(yearForPreviousMonth, previousMonth, labelFromPreviousMonth),
      };
      day.date.setHours(0, 0, 0, 0);

      if (this.selectedDate) {
        if (day.date.getTime() == this.selectedDate.getTime()) {
          day.selected = true;
        }
      }

      if (this.maxDate) {
        if (day.date.getTime() > this.maxDate.getTime()) {
          day.disabled = true;
        }
      }

      if (this.minDate) {
        if (day.date.getTime() < this.minDate.getTime()) {
          day.disabled = true;
        }
      }

      days.push(day);
    }

    var labelFromThisMonth: number;
    for (labelFromThisMonth = 1; labelFromThisMonth <= numberOfDaysInDisplayedMonth; labelFromThisMonth++) {
      var day: Day = {
        label: labelFromThisMonth,
        today: false,
        selected: false,
        previousMonth: false,
        nextMonth: false,
        disabled: false,
        date: new Date(year, month, labelFromThisMonth)
      };
      day.date.setHours(0, 0, 0, 0);

      if (day.date.getTime() == this.today.getTime()) {
        day.today = true;
      }

      if (this.selectedDate) {
        if (day.date.getTime() == this.selectedDate.getTime()) {
          day.selected = true;
        }
      }

      if (this.maxDate) {
        if (day.date.getTime() > this.maxDate.getTime()) {
          day.disabled = true;
        }
      }

      if (this.minDate) {
        if (day.date.getTime() < this.minDate.getTime()) {
          day.disabled = true;
        }
      }

      days.push(day);
    }

    var totalNumberOfWeeks = 5;
    if (days.length > 35) {
      totalNumberOfWeeks = 6;
    } else if (days.length < 29) {
      totalNumberOfWeeks = 4;
    }

    var nextMonth: number;
    var yearForNextMonth: number;
    if (month == 11) {
      nextMonth = 0;
      yearForNextMonth = year + 1;
    } else {
      nextMonth = month + 1;
      yearForNextMonth = year;
    }
    ;

    var daysFromNextMonth = totalNumberOfWeeks * 7 - days.length;
    var labelFromNextMonth: number;
    for (labelFromNextMonth = 1; labelFromNextMonth <= daysFromNextMonth; labelFromNextMonth++) {
      var day: Day = {
        label: labelFromNextMonth,
        today: false,
        selected: false,
        previousMonth: false,
        nextMonth: true,
        disabled: false,
        date: new Date(yearForNextMonth, nextMonth, labelFromNextMonth)
      };
      day.date.setHours(0, 0, 0, 0);

      if (this.selectedDate) {
        if (day.date.getTime() == this.selectedDate.getTime()) {
          day.selected = true;
        }
      }

      if (this.maxDate) {
        if (day.date.getTime() > this.maxDate.getTime()) {
          day.disabled = true;
        }
      }

      if (this.minDate) {
        if (day.date.getTime() < this.minDate.getTime()) {
          day.disabled = true;
        }
      }

      days.push(day);
    }

    return days;
  }
}
