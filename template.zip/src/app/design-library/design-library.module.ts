import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ShowcaseComponent} from './showcase/showcase.component';
import {ModalComponent} from './modal/modal.component';
import {DatePickerComponent} from './date-picker/date-picker.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {LoadingSpinnerComponent} from './loading-spinner/loading-spinner.component';
import {LoadingSpinnerOverlayComponent} from './loading-spinner-overlay/loading-spinner-overlay.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    ShowcaseComponent,
    ModalComponent,
    DatePickerComponent,
    LoadingSpinnerComponent,
    LoadingSpinnerOverlayComponent
  ],
  exports: [
    ShowcaseComponent,
    ModalComponent,
    DatePickerComponent,
    LoadingSpinnerComponent,
    LoadingSpinnerOverlayComponent
  ]
})
export class DesignLibraryModule {
}
